/*******************
*Name: Aaron Doss
*Course: CS-320
*Date: 5/25/24
*
***********************/

package mainFiles;

import java.util.ArrayList;

public class ContactService{
	
	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	public void displayContactList() {
		
		for (int counter = 0; counter < contactList.size(); counter++) {
			System.out.println("\t Contact ID: " + contactList.get(counter).getContactID());
			System.out.println("\t First Name: " + contactList.get(counter).getFirstName());
			System.out.println("\t Last Name: " + contactList.get(counter).getLastName());
			System.out.println("\t Phone Number: " + contactList.get(counter).getNumber());
			System.out.println("\t Address: " + contactList.get(counter).getAddress() + "\n");
		}
	}
	//add new contact and assign to list
	public void addContact(String firstName, String lastName, String num, String address) {
		
		Contact contact = new Contact(firstName, lastName, num, address);
		contactList.add(contact);
		
	}
	
	//if matching contact isn't found return with default values
	public Contact getContact(String contactID) {
		
		Contact contact = new Contact(null, null, null, null);
		
		for (int i = 0; i < contactList.size(); i++) {
			
			if(contactList.get(i).getContactID().contentEquals(contactID)) {
				
				contact = contactList.get(i);
			}
		}
		
		return contact;
	}
	
	public void deleteContact(String contactID) {
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if (contactList.get(i).getContactID().equals(contactID)) {
				
				contactList.remove(i);
				break;
			}
			
			if(i == contactList.size()-1) {
				
				System.out.println("Contact ID: " + contactID + " wasn't found.");
				
			}
		}
	}
	
	public void updateFirstName(String updatedString, String contactID) {
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if (contactList.get(i).getContactID().equals(contactID)) {
				
				contactList.get(i).setFirstName(updatedString);
				break;
			}
			if (i == contactList.size()-1) {
				
				System.out.println("Contact ID: " + contactID + " wasn't found.");
			}
		}
	}
	
	public void updateLastName(String updatedString, String contactID) {
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if (contactList.get(i).getContactID().equals(contactID)) {
				
				contactList.get(i).setLastName(updatedString);
				break;
			}
			if (i == contactList.size()-1) {
				
				System.out.println("Contact ID: " + contactID + " wasn't found.");
			}
		}
	}
	
	public void updateNumber(String updatedString, String contactID) {
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if(contactList.get(i).getContactID().equals(contactID)) {
				
				contactList.get(i).setNumber(updatedString);
				break;
			}
			if (i == contactList.size()-1) {
				
				System.out.println("Contact ID: " + contactID + " wasn't found.");
			}
		}
	}
	
	public void updateAddress(String updatedString, String contactID) {
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if(contactList.get(i).getContactID().equals(contactID)) {
				
				contactList.get(i).setAddress(updatedString);
				break;
			}
			if(i == contactList.size()- 1) {
				
				System.out.println("Contact ID: " + contactID + " wasn't found.");
			}
		}
	}
	
}