/************************
*Name: Aaron Doss
*Course: CS 320
*Date: 5/31/24
*************************/

package mainFiles;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService{
	
	private final List<Task> taskList = new ArrayList<>();
	
	private String newUniqueId() {
		
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
		
	}
	
	private Task searchForTask(String id) throws Exception{
		int i = 0;
		
		while(i < taskList.size()) {
			
			if (id.equals(taskList.get(i).getTaskId())) {
				
				return taskList.get(i);
				
			}
			
			i++;
			
		}
		
		throw new Exception("Task doesn't exist.");
		
	}
	
	public void newTask() {
		
		Task task = new Task(newUniqueId());
		taskList.add(task);
		
	}
	
	public void newTask(String taskName) {
		
		Task task = new Task(newUniqueId(), taskName);
		taskList.add(task);
		
	}
	
	public void newTask(String taskName, String taskDescript) {
		
		Task task = new Task(newUniqueId());
		taskList.add(task);
		
	}
	
	public void deleteTask(String taskId) throws Exception{
		
		taskList.remove(searchForTask(taskId));
		
	}
	
	public void updateName(String taskId, String taskName) throws Exception{
		
		searchForTask(taskId).setName(taskName);
		
	}
	
	public void updateDescript(String taskId, String taskDescript) throws Exception{
		
		searchForTask(taskId).setTaskDescript(taskDescript);
		
	}
	
	public List<Task> getTaskList(){
		
		return taskList;
		
	}
}