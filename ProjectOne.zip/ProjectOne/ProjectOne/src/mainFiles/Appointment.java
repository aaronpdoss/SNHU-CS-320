/*******************
 * Name: Aaron Doss
 * Course: CS-320
 * Date 6/8/24
 *******************/

package mainFiles;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Calendar;
import java.util.Date;

@SuppressWarnings("deprecation")
public class Appointment {

	private final String appointmentId;
	private Date appointmentDate;
	private String appointmentDescript;
	private static AtomicLong idGen = new AtomicLong();
	
	@SuppressWarnings("deprecation")
	public Appointment(Date appointmentDate, String appointmentDescript) {
		
		this.appointmentId = String.valueOf(idGen.getAndIncrement());
		
		if(appointmentDate == null) {
			
			this.appointmentDate = new Date(2024, Calendar.JUNE, 1);
			
		}else if(appointmentDate.before(new Date())) {
			
			throw new IllegalArgumentException("Can't make appointment before the current date.");
			
		}else {
			
			this.appointmentDate = appointmentDate;
			
		}
		
		if(appointmentDescript == null || appointmentDescript.isEmpty()) {
			
			this.appointmentDescript = "NULL";
			
		}else if(appointmentDescript.length() > 50) {
			
			this.appointmentDescript = appointmentDescript.substring(0, 50);
			
		}else {
			
			this.appointmentDescript = appointmentDescript;
			
		}
	}
	
	//Getter methods
	public String getAppointmentId() {
		
		return appointmentId;
		
	}
	
	public Date getAppointmentDate() {
		
		return appointmentDate;
		
	}
	
	public String getAppointmentDescript() {
		
		return appointmentDescript;
		
	}
	
	//setter methods
	@SuppressWarnings("deprecation")
	public void setAppointmentDate(Date appointmentDate) {
	
	if(appointmentDate == null) {
		
		appointmentDate = new Date(2024, Calendar.JUNE, 1);
		
	}else if(appointmentDate.before(new Date())) {
		
		throw new IllegalArgumentException("Can't make appointment before  the current date.");
		
	}else {
		
		this.appointmentDate = appointmentDate;
		
	}
}
	
	public void setAppointmentDescript(String appointmentDescript) {
		
		if(appointmentDescript == null || appointmentDescript.isEmpty()) {
			
			this.appointmentDescript = "NULL";
			
		}else if(appointmentDescript.length() > 50) {
			
			this.appointmentDescript = appointmentDescript.substring(0, 50);
			
		}else {
			
			this.appointmentDescript = appointmentDescript;
			
		}
	}
}