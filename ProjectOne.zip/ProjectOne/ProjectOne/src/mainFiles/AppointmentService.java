/*******************
 * Name: Aaron Doss
 * Course: CS-320
 * Date 6/8/24
 *******************/

package mainFiles;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	public void displayAppointmentList() {
		
		for (int i = 0; i < appointmentList.size(); i++) {
			
			System.out.println("\t Appointment ID: " + appointmentList.get(i).getAppointmentId());
			System.out.println("\t Appointment Date: " + appointmentList.get(i).getAppointmentDate());
			System.out.println("\t Appointment Description: " + appointmentList.get(i).getAppointmentDescript());
			
		}
		
	}
	
	public void addAppointment(Date appointmentDate, String appointmentDescript) {
		
		//add new appointment
		Appointment appointment = new Appointment(appointmentDate, appointmentDescript);
		appointmentList.add(appointment);
		
	}
	
	public Appointment getAppointment(String appointmentId) {
		
		Appointment appointment = new Appointment(null, null);
		
		for(int i = 0; i < appointmentList.size(); i++) {
			
			if(appointmentList.get(i).getAppointmentId().contentEquals(appointmentId)) {
				
				appointment = appointmentList.get(i);
				
			}
		}
		
		return appointment;
		
	}
	
	//delete appointment, if no appointment found then print error msg
	public void deleteAppointment(String appointmentId) {
		
		for(int i = 0; i < appointmentList.size(); i++) {
			
			if(appointmentList.get(i).getAppointmentId().equals(appointmentId)) {
				
				appointmentList.remove(i);
				break;
				
			}
			
			if(i == appointmentList.size() - 1) {
				
				System.out.println("Appointment ID: " + " wasn't found.");
				
			}
		}
	}
	
	//update appointment date
	public void updateAppointmentDate(Date newDate, String appointmentId) {
		
		for(int i = 0; i < appointmentList.size(); i++) {
			
			if(appointmentList.get(i).getAppointmentId().equals(appointmentId)) {
				
				appointmentList.get(i).setAppointmentDate(newDate);
				break;
				
			}
			
			if(i == appointmentList.size()-1) {
				
				System.out.println("Appointment ID: " + " wasn't found.");
				
			}
		}
	}
	
	//update appointment description
	public void updateAppointmentDescript(String newDescription, String appointmentId) {
		
		for(int i = 0; i < appointmentList.size(); i++) {
			
			if(appointmentList.get(i).getAppointmentId().equals(appointmentId)) {
				
				appointmentList.get(i).setAppointmentDescript(newDescription);
				break;
				
			}
			
			if(i == appointmentList.size() - 1) {
				
				System.out.println("Appointment ID: " + " wasn't found.");
				
			}
		}
	}
}