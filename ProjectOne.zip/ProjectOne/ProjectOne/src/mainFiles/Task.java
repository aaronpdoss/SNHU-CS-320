/************************
*Name: Aaron Doss
*Course: CS 320
*Date: 5/31/24
*************************/

package mainFiles;


public class Task{
	
	private String taskId;
	private String taskName;
	private String taskDescript;
	
	public Task(){
		
		taskId = "taskId";
		taskName = "taskName";
		taskDescript = "taskDescript";
		
	}
	
	public Task(String taskId){
		
		checkTaskId(taskId);
		taskName = "taskName";
		taskDescript = "taskDescript";
		
	}
	
	public Task(String taskId, String taskName){
		
		checkTaskId(taskId);
		setName(taskName);
		taskDescript = "taskDescript";
		
	}
	
	public String getTaskId() {
		
		return taskId;
		
	}
	
	public String getTaskName() {
		
		return taskName;
		
	}
	
	public String getTaskDescript() {
		
		return taskDescript;
		
	}
	
	public void setName(String taskName) {
		
		if(taskName == null || taskName.length() > 20) {
			
			throw new IllegalArgumentException("Task name is invalid.");
		}else {
			
			this.taskName = taskName;
			
		}
	}
	
	public void setTaskDescript(String taskDescript) {
		
		if(taskDescript == null || taskDescript.length() > 50) {
			
			throw new IllegalArgumentException("Task description is invalid.");
			
		}else {
			
			this.taskDescript = taskDescript;
			
		}
	}
	
	void checkTaskId(String taskId) {
		
		if(taskId == null || taskId.length()> 10) {
			
			throw new IllegalArgumentException("Task ID was longer than 10 chars");
		
		}else {
			
			this.taskId = taskId;
		}
	}
	
}