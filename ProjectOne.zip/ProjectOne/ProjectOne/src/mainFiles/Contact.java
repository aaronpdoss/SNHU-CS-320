/*******************
*Name: Aaron Doss
*Course: CS-320
*Date: 5/25/24
*
***********************/

package mainFiles;

import java.util.concurrent.atomic.AtomicLong;

public class Contact{
	
	private final String contactID;
	private String firstName;
	private String lastName;
	private String num;
	private String address;
	private static AtomicLong idGen = new AtomicLong();
	


	public Contact (String firstName, String lastName, String num, String address) {
	
		this.contactID = String.valueOf(idGen.getAndIncrement());
	
		//handling firstName
		if (firstName == null || firstName.isEmpty()) {
		
			this.firstName = "NULL";
	
		}
		else if (firstName.length() > 10) {
		
			this.firstName = firstName.substring(0, 10);
		
		}
		else {
			
			this.firstName = firstName;
			
		}
		
		//handling lastName
		if (lastName == null || lastName.isEmpty()) {
			
			this.lastName = "NULL";
			
		}
		else if(lastName.length() > 10) {
			
			this.lastName = lastName.substring(0, 10);
			
		}
		else {
			
			this.lastName = lastName;
			
		}
		
		//handling num
		if(num == null || num.isEmpty() || num.length() != 10) {
			
			this.num = "0000000000";
			
		}
		else {
			
			this.num = num;
			
		}
		
		//handling address
		if (address == null || address.isEmpty()) {
			
			this.address = "NULL";
			
		}
		else if (address.length() > 30) {
			
			this.address = address.substring(0, 30);
			
		}
		else {
			
			this.address = address;
		}
		
	}


	//getter methods
	public String getContactID() {
	
		return contactID;
	
	}
	
	public String getFirstName() {
		
		return firstName;
		
	}
	
	public String getLastName() {
		
		return lastName;
		
	}
	
	public String getNumber() {
		
		return num;
		
	}
	
	public String getAddress() {
		
		return address;
	}
	
	
	//setter methods
	public void setFirstName(String firstName) {
		
		if (firstName == null || firstName.isEmpty()) {
			
			this.firstName = "NULL";
	
		}
		else if (firstName.length() > 10) {
		
			this.firstName = firstName.substring(0, 10);
		
		}
		else {
			
			this.firstName = firstName;
			
		}
		
	}
	
	public void setLastName(String lastName) {
		
		if (lastName == null || lastName.isEmpty()) {
			
			this.lastName = "NULL";
			
		}
		else if(lastName.length() > 10) {
			
			this.lastName = lastName.substring(0, 10);
			
		}
		else {
			
			this.lastName = lastName;
			
		}

	}
	
	public void setNumber(String num) {
		
		if(num == null || num.isEmpty() || num.length() != 10) {
			
			this.num = "0000000000";
			
		}
		else {
			
			this.num = num;
			
		}
		
	}
	
	public void setAddress(String address) {
		
		if (address == null || address.isEmpty()) {
			
			this.address = "NULL";
			
		}
		else if (address.length() > 30) {
			
			this.address = address.substring(0, 30);
			
		}
		else {
			
			this.address = address;
		}
	}
}

