package testFiles;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import mainFiles.Contact;
import mainFiles.ContactService;

import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)

public class ContactServiceTest{
	
	@Test
	@DisplayName("Test to update First Name.")
	@Order(1)
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.updateFirstName("Sven", "9");
		service.displayContactList();
		assertEquals("Sven", service.getContact("9").getFirstName(), "First name was not updated.");
	}
	
	@Test
	@DisplayName("Test to update Last Name.")
	@Order(2)
	void testUpdateLastName() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.updateLastName("Waller", "10");
		service.displayContactList();
		assertEquals("Shirley", service.getContact("10").getLastName(), "Last name was not updated.");
	}
	
	@Test
	@DisplayName("Test to update phone number.")
	@Order(3)
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.updateNumber("5554443322", "17");
		//service.displayContactList();
		assertEquals("5554443322", service.getContact("17").getNumber(), "Phone number was not updated.");
	}
	
	@Test
	@DisplayName("Test to update address.")
	@Order(4)
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.updateAddress("432 Jeff Ave", "19");
		service.displayContactList();
		assertEquals("432 Jeff Ave", service.getContact("19").getAddress(), "Address was not updated.");
	}
	
	@Test
	@DisplayName("Test to ensure that service correctly deletes contacts.")
	@Order(5)
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.deleteContact("19");
		// Ensure that the contactList is now empty by creating a new empty contactList to compare it with
		ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
		service.displayContactList();
		assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
	}
	
	@Test
	@DisplayName("Test to ensure that service can add a contact.")
	@Order(6)
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("Aaron", "Doss", "4445552524", "234 Maple Street");
		service.displayContactList();
		assertNotNull(service.getContact("0"), "Contact was not added correctly.");
	}
}
