package testFiles;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import mainFiles.Appointment;
import mainFiles.AppointmentService;

class AppointmentServiceTest {

	private Date Date(int i, int january, int j) {
		
		return null;
	}
	
	@Test
	@DisplayName("Test to update appointment date")
	@Order(1)
	void testUpdateAppointmentDate() {
		
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JUNE, 8), "Description");
		service.updateAppointmentDate(Date(2025, Calendar.JULY, 9), "sick");
		service.displayAppointmentList();
		assertEquals(Date(2025, Calendar.JULY, 9), service.getAppointment("sick").getAppointmentDate(), "Appointment date was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to update appointment description.")
	@Order(2)
	void testUpdateAppointmentDesc() {
		
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JUNE, 8), "Description");
		service.updateAppointmentDescript("Updated Description", "9");
		service.displayAppointmentList();
		assertEquals("Updated Description", service.getAppointment("9").getAppointmentDescript(), "Appointment description was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to ensure that service correctly deletes appointments.")
	@Order(3)
	void testDeleteAppointment() {
		
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JUNE, 8), "Description");
		service.deleteAppointment("11");
		
		// Ensure that the AppointmentList is now empty 
		ArrayList<Appointment> appointmentListEmpty = new ArrayList<Appointment>();
		service.displayAppointmentList();
		assertEquals(service.appointmentList, appointmentListEmpty, "The appointment was not deleted.");
		
	}
	
	@Test
	@DisplayName("Test to ensure that service can add an appointment.")
	@Order(4)
	void testAddAppointment() {
		
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JUNE, 8), "Description");
		service.displayAppointmentList();
		assertNotNull(service.getAppointment("1"), "Appointment was not added correctly.");
		
	}

}