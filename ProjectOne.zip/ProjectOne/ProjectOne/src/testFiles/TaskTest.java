package testFiles;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import mainFiles.Task;
import mainFiles.TaskService;

class TaskTest{
	
	private String id, taskName, taskDescript;
	  private String tooLongId, tooLongName, tooLongDescription;

	  @BeforeEach
	  void setUp() {
		  
	    id = "1234567890";
	    taskName = "This is Twenty Chars";
	    taskDescript = "The task object shall have a required description.";
	    tooLongId = "111222333444555666777888999";
	    tooLongName = "This is way too long to be a task name";
	    tooLongDescription = "The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.";
	    
	  }

	  @Test
	  void getTaskIdTest() {
	    Task task = new Task(id);
	    Assertions.assertEquals(id, task.getTaskId());
	  }

	  @Test
	  void getNameTest() {
	    Task task = new Task(id, taskName);
	    Assertions.assertEquals(taskName, task.getTaskName());
	  }

	  @Test
	  void getDescriptionTest() {
		  
	    Task task = new Task(id, taskName);
	    Assertions.assertEquals(taskDescript, task.getTaskDescript());
	    
	  }

	  @Test
	  void setNameTest() {
	    Task task = new Task();
	    task.setName(taskName);
	    Assertions.assertEquals(taskName, task.getTaskName());
	  }

	  @Test
	  void setDescriptionTest() {
	    Task task = new Task();
	    task.setTaskDescript(taskDescript);
	    Assertions.assertEquals(taskDescript, task.getTaskDescript());
	  }

	  @Test
	  void TaskIdTooLongTest() {
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> new Task(tooLongId));
	  }

	  @Test
	  void setTooLongNameTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setName(tooLongName));
	  }

	  @Test
	  void setTooLongDescriptionTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setTaskDescript(tooLongDescription));
	  }

	  @Test
	  void TaskIdNullTest() {
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> new Task(null));
	  }

	  @Test
	  void TaskNameNullTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setName(null));
	  }

	  @Test
	  void TaskDescriptionNullTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setTaskDescript(null));
	  }
}